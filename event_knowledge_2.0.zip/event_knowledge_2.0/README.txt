Hello! This is the data release version 2.0 (include all narrative texts extracted by the method in this paper).

Acquired event knowledge in the paper "Temporal Event Knowledge Acquisition via Identifying Narratives" (ACL 2018) is available at:
http://nlp.cs.tamu.edu/People/WenlinYao_files/EventNarratives/event_knowledge_2.0.zip

*** Note that this resource can only be used for research purpose. ***
*** All copyright belongs to the original authors. ***

For more copyright information, please refer to:
https://catalog.ldc.upenn.edu/LDC2003T05
http://yknzhu.wixsite.com/mbweb



Citation:
@InProceedings{P18-1050,
  author = 	"Yao, Wenlin
		and Huang, Ruihong",
  title = 	"Temporal Event Knowledge Acquisition via Identifying Narratives",
  booktitle = 	"Proceedings of the 56th Annual Meeting of the Association for Computational Linguistics (Volume 1: Long Papers)",
  year = 	"2018",
  publisher = 	"Association for Computational Linguistics",
  pages = 	"537--547",
  location = 	"Melbourne, Australia",
  url = 	"http://aclweb.org/anthology/P18-1050"
}